﻿USE [master]
GO
IF DB_ID('CitasMedicasDB') IS NULL CREATE DATABASE [CitasMedicasDB]
GO
IF SUSER_ID('citasapp') IS NULL CREATE LOGIN [citasapp] WITH PASSWORD = N'Citas2026*', CHECK_POLICY = OFF
GO
USE [CitasMedicasDB]
GO
/****** Objeto: User [citasapp] Fecha de script: 1/7/2026 02:14:29 ******/
CREATE USER [citasapp] FOR LOGIN [citasapp] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [citasapp]
GO
/****** Objeto: Table [dbo].[citas] Fecha de script: 1/7/2026 02:14:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[citas](
	[id_cita] [int] IDENTITY(1,1) NOT NULL,
	[id_paciente] [int] NOT NULL,
	[id_medico] [int] NOT NULL,
	[fecha] [date] NOT NULL,
	[hora] [time](7) NOT NULL,
	[estado] [varchar](20) NOT NULL,
	[fecha_registro] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id_cita] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Objeto: Table [dbo].[historial] Fecha de script: 1/7/2026 02:14:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[historial](
	[id_historial] [int] IDENTITY(1,1) NOT NULL,
	[id_cita] [int] NOT NULL,
	[evento] [varchar](200) NOT NULL,
	[fecha_evento] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id_historial] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Objeto: Table [dbo].[medicos] Fecha de script: 1/7/2026 02:14:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[medicos](
	[id_medico] [int] IDENTITY(1,1) NOT NULL,
	[cedula] [varchar](10) NOT NULL,
	[nombres] [varchar](80) NOT NULL,
	[apellidos] [varchar](80) NOT NULL,
	[especialidad] [varchar](80) NOT NULL,
	[correo] [varchar](120) NULL,
	[telefono] [varchar](20) NULL,
	[estado] [varchar](20) NOT NULL,
	[fecha_registro] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id_medico] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Objeto: Table [dbo].[notificaciones] Fecha de script: 1/7/2026 02:14:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[notificaciones](
	[id_notificacion] [int] IDENTITY(1,1) NOT NULL,
	[id_paciente] [int] NOT NULL,
	[mensaje] [varchar](300) NOT NULL,
	[fecha_envio] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id_notificacion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Objeto: Table [dbo].[pacientes] Fecha de script: 1/7/2026 02:14:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[pacientes](
	[id_paciente] [int] IDENTITY(1,1) NOT NULL,
	[cedula] [varchar](10) NOT NULL,
	[nombres] [varchar](80) NOT NULL,
	[apellidos] [varchar](80) NOT NULL,
	[telefono] [varchar](20) NULL,
	[correo] [varchar](120) NULL,
	[fecha_registro] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id_paciente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[citas] ON 

INSERT [dbo].[citas] ([id_cita], [id_paciente], [id_medico], [fecha], [hora], [estado], [fecha_registro]) VALUES (1, 1, 1, CAST(N'2026-07-05' AS Date), CAST(N'09:00:00' AS Time), N'Atendida', CAST(N'2026-06-29T23:25:14.357' AS DateTime))
INSERT [dbo].[citas] ([id_cita], [id_paciente], [id_medico], [fecha], [hora], [estado], [fecha_registro]) VALUES (2, 2, 2, CAST(N'2026-07-06' AS Date), CAST(N'10:30:00' AS Time), N'Atendida', CAST(N'2026-06-29T23:25:14.357' AS DateTime))
SET IDENTITY_INSERT [dbo].[citas] OFF
GO
SET IDENTITY_INSERT [dbo].[historial] ON 

INSERT [dbo].[historial] ([id_historial], [id_cita], [evento], [fecha_evento]) VALUES (1, 1, N'Estado de la cita cambiado a: Atendida', CAST(N'2026-06-30T00:19:09.487' AS DateTime))
INSERT [dbo].[historial] ([id_historial], [id_cita], [evento], [fecha_evento]) VALUES (2, 2, N'Estado de la cita cambiado a: Atendida', CAST(N'2026-06-30T00:28:34.720' AS DateTime))
SET IDENTITY_INSERT [dbo].[historial] OFF
GO
SET IDENTITY_INSERT [dbo].[medicos] ON 

INSERT [dbo].[medicos] ([id_medico], [cedula], [nombres], [apellidos], [especialidad], [correo], [telefono], [estado], [fecha_registro]) VALUES (1, N'0934567890', N'Alex', N'Reyes', N'Medicina General', N'alex@hospital.com', N'0976543210', N'ACTIVO', CAST(N'2026-06-29T23:25:14.337' AS DateTime))
INSERT [dbo].[medicos] ([id_medico], [cedula], [nombres], [apellidos], [especialidad], [correo], [telefono], [estado], [fecha_registro]) VALUES (2, N'0945678901', N'Gabriel', N'Cejido', N'Pediatria', N'gabriel@hospital.com', N'0965432109', N'INACTIVO', CAST(N'2026-06-29T23:25:14.337' AS DateTime))
SET IDENTITY_INSERT [dbo].[medicos] OFF
GO
SET IDENTITY_INSERT [dbo].[notificaciones] ON 

INSERT [dbo].[notificaciones] ([id_notificacion], [id_paciente], [mensaje], [fecha_envio]) VALUES (1, 1, N'El estado de su cita cambio a: Atendida', CAST(N'2026-06-30T00:19:09.503' AS DateTime))
INSERT [dbo].[notificaciones] ([id_notificacion], [id_paciente], [mensaje], [fecha_envio]) VALUES (2, 2, N'El estado de su cita cambio a: Atendida', CAST(N'2026-06-30T00:28:34.730' AS DateTime))
SET IDENTITY_INSERT [dbo].[notificaciones] OFF
GO
SET IDENTITY_INSERT [dbo].[pacientes] ON 

INSERT [dbo].[pacientes] ([id_paciente], [cedula], [nombres], [apellidos], [telefono], [correo], [fecha_registro]) VALUES (1, N'0912345678', N'Karla', N'Martillo', N'0991234567', N'karla@example.com', CAST(N'2026-06-29T23:25:14.320' AS DateTime))
INSERT [dbo].[pacientes] ([id_paciente], [cedula], [nombres], [apellidos], [telefono], [correo], [fecha_registro]) VALUES (2, N'0923456789', N'Dave', N'Guaranda', N'0987654321', N'dave@example.com', CAST(N'2026-06-29T23:25:14.320' AS DateTime))
INSERT [dbo].[pacientes] ([id_paciente], [cedula], [nombres], [apellidos], [telefono], [correo], [fecha_registro]) VALUES (3, N'0202224317', N'Gabriel isaac', N'Cejido Centeno', N'0986105101', N'Gabriel_1234centeno@hotmail.com', CAST(N'2026-06-30T00:07:39.227' AS DateTime))
SET IDENTITY_INSERT [dbo].[pacientes] OFF
GO
SET ANSI_PADDING ON
GO
/****** Objeto: Index [UQ__medicos__415B7BE53261E463] Fecha de script: 1/7/2026 02:14:29 ******/
ALTER TABLE [dbo].[medicos] ADD UNIQUE NONCLUSTERED 
(
	[cedula] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Objeto: Index [UQ__paciente__415B7BE535ED8ADB] Fecha de script: 1/7/2026 02:14:29 ******/
ALTER TABLE [dbo].[pacientes] ADD UNIQUE NONCLUSTERED 
(
	[cedula] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[citas] ADD  DEFAULT ('Pendiente') FOR [estado]
GO
ALTER TABLE [dbo].[citas] ADD  DEFAULT (getdate()) FOR [fecha_registro]
GO
ALTER TABLE [dbo].[historial] ADD  DEFAULT (getdate()) FOR [fecha_evento]
GO
ALTER TABLE [dbo].[medicos] ADD  DEFAULT ('ACTIVO') FOR [estado]
GO
ALTER TABLE [dbo].[medicos] ADD  DEFAULT (getdate()) FOR [fecha_registro]
GO
ALTER TABLE [dbo].[notificaciones] ADD  DEFAULT (getdate()) FOR [fecha_envio]
GO
ALTER TABLE [dbo].[pacientes] ADD  DEFAULT (getdate()) FOR [fecha_registro]
GO
ALTER TABLE [dbo].[citas]  WITH CHECK ADD  CONSTRAINT [FK_citas_medico] FOREIGN KEY([id_medico])
REFERENCES [dbo].[medicos] ([id_medico])
GO
ALTER TABLE [dbo].[citas] CHECK CONSTRAINT [FK_citas_medico]
GO
ALTER TABLE [dbo].[citas]  WITH CHECK ADD  CONSTRAINT [FK_citas_paciente] FOREIGN KEY([id_paciente])
REFERENCES [dbo].[pacientes] ([id_paciente])
GO
ALTER TABLE [dbo].[citas] CHECK CONSTRAINT [FK_citas_paciente]
GO
ALTER TABLE [dbo].[historial]  WITH CHECK ADD  CONSTRAINT [FK_historial_cita] FOREIGN KEY([id_cita])
REFERENCES [dbo].[citas] ([id_cita])
GO
ALTER TABLE [dbo].[historial] CHECK CONSTRAINT [FK_historial_cita]
GO
ALTER TABLE [dbo].[notificaciones]  WITH CHECK ADD  CONSTRAINT [FK_notificaciones_paciente] FOREIGN KEY([id_paciente])
REFERENCES [dbo].[pacientes] ([id_paciente])
GO
ALTER TABLE [dbo].[notificaciones] CHECK CONSTRAINT [FK_notificaciones_paciente]
GO
USE [master]
GO
ALTER DATABASE [CitasMedicasDB] SET  READ_WRITE 
GO
