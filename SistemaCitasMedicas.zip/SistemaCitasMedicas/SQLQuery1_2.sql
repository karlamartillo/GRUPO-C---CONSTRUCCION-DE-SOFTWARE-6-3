USE [master];
GO
ALTER LOGIN [citasapp] WITH PASSWORD = N'Citas2026*', CHECK_POLICY = OFF;
ALTER LOGIN [citasapp] ENABLE;
ALTER LOGIN [citasapp] WITH DEFAULT_DATABASE = [CitasMedicasDB];
GO
USE [CitasMedicasDB];
GO
SELECT name FROM sys.database_principals WHERE name = 'citasapp';