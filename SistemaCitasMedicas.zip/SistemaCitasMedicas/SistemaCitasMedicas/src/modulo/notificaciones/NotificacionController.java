package modulo.notificaciones;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modulo.conexion.Conexion;

/**
 * Controlador del modulo Notificaciones.
 * Version corregida: el original solo hacia System.out.println()
 * en la consola y no guardaba nada. Ahora cada notificacion se
 * guarda en la tabla "notificaciones" asociada al paciente real,
 * y queda disponible para mostrarla en la interfaz grafica.
 */
public class NotificacionController {

    private final Connection conexion;

    public NotificacionController() {
        this.conexion = Conexion.getInstancia().getConexion();
    }

    /**
     * Genera y persiste una notificacion para un paciente.
     */
    public boolean notificarPaciente(int idPaciente, String mensaje) {
        String sql = "INSERT INTO notificaciones (id_paciente, mensaje) VALUES (?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPaciente);
            ps.setString(2, mensaje);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al generar notificacion:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Lista las notificaciones de un paciente especifico.
     */
    public ArrayList<String> listarPorPaciente(int idPaciente) {
        ArrayList<String> lista = new ArrayList<>();
        String sql = "SELECT mensaje, fecha_envio FROM notificaciones "
                + "WHERE id_paciente = ? ORDER BY fecha_envio DESC";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPaciente);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add("[" + rs.getTimestamp("fecha_envio") + "] " + rs.getString("mensaje"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar notificaciones:\n" + ex.getMessage());
        }
        return lista;
    }

    /**
     * Llena una tabla de Swing con todas las notificaciones (vista de administrador).
     */
    public void cargarTablaNotificaciones(DefaultTableModel modeloTabla) {
        modeloTabla.setRowCount(0);
        String sql = "SELECT n.id_notificacion, p.nombres + ' ' + p.apellidos AS paciente, "
                + "n.mensaje, n.fecha_envio "
                + "FROM notificaciones n "
                + "INNER JOIN pacientes p ON n.id_paciente = p.id_paciente "
                + "ORDER BY n.fecha_envio DESC";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id_notificacion"),
                    rs.getString("paciente"),
                    rs.getString("mensaje"),
                    rs.getTimestamp("fecha_envio")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar notificaciones:\n" + ex.getMessage());
        }
    }
}
