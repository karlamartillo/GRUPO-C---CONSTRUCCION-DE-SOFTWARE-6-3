package modulo.notificaciones;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana que muestra el historial de eventos de citas y las
 * notificaciones generadas para los pacientes.
 */
public class VistaHistorialNotificacion extends JFrame {

    private final HistorialController historialController = new HistorialController();
    private final NotificacionController notificacionController = new NotificacionController();

    public VistaHistorialNotificacion() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Historial y Notificaciones");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        DefaultTableModel modeloHistorial = new DefaultTableModel(
                new Object[]{"ID", "ID Cita", "Evento", "Fecha"}, 0);
        JTable tablaHistorial = new JTable(modeloHistorial);
        historialController.cargarTablaHistorial(modeloHistorial);
        tabs.addTab("Historial", new JScrollPane(tablaHistorial));

        DefaultTableModel modeloNotificaciones = new DefaultTableModel(
                new Object[]{"ID", "Paciente", "Mensaje", "Fecha de envio"}, 0);
        JTable tablaNotificaciones = new JTable(modeloNotificaciones);
        notificacionController.cargarTablaNotificaciones(modeloNotificaciones);
        tabs.addTab("Notificaciones", new JScrollPane(tablaNotificaciones));

        add(tabs);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new VistaHistorialNotificacion().setVisible(true));
    }
}
