package modulo.notificaciones;

import java.sql.Timestamp;

public class HistorialEvento {

    private int idHistorial;
    private int idCita;
    private String evento;
    private Timestamp fechaEvento;

    public HistorialEvento() {
    }

    public HistorialEvento(int idHistorial, int idCita, String evento, Timestamp fechaEvento) {
        this.idHistorial = idHistorial;
        this.idCita = idCita;
        this.evento = evento;
        this.fechaEvento = fechaEvento;
    }

    public int getIdHistorial() { return idHistorial; }
    public void setIdHistorial(int idHistorial) { this.idHistorial = idHistorial; }

    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }

    public String getEvento() { return evento; }
    public void setEvento(String evento) { this.evento = evento; }

    public Timestamp getFechaEvento() { return fechaEvento; }
    public void setFechaEvento(Timestamp fechaEvento) { this.fechaEvento = fechaEvento; }
}
