package modulo.notificaciones;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modulo.conexion.Conexion;

/**
 * Controlador del modulo Historial.
 * Version corregida: en el original, Historial solo guardaba texto
 * en un ArrayList que se perdia al cerrar el programa. Ahora cada
 * evento queda persistido en la tabla "historial" y asociado a una
 * cita real mediante id_cita.
 */
public class HistorialController {

    private final Connection conexion;

    public HistorialController() {
        this.conexion = Conexion.getInstancia().getConexion();
    }

    /**
     * Registra un nuevo evento en el historial de una cita.
     */
    public boolean registrarEvento(int idCita, String evento) {
        String sql = "INSERT INTO historial (id_cita, evento) VALUES (?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idCita);
            ps.setString(2, evento);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al registrar evento en historial:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Lista todos los eventos del historial de una cita especifica.
     */
    public ArrayList<HistorialEvento> listarPorCita(int idCita) {
        ArrayList<HistorialEvento> lista = new ArrayList<>();
        String sql = "SELECT id_historial, id_cita, evento, fecha_evento "
                + "FROM historial WHERE id_cita = ? ORDER BY fecha_evento";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idCita);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new HistorialEvento(
                        rs.getInt("id_historial"),
                        rs.getInt("id_cita"),
                        rs.getString("evento"),
                        rs.getTimestamp("fecha_evento")
                ));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar historial:\n" + ex.getMessage());
        }
        return lista;
    }

    /**
     * Lista el historial completo de todas las citas (para reportes).
     */
    public ArrayList<HistorialEvento> listarTodo() {
        ArrayList<HistorialEvento> lista = new ArrayList<>();
        String sql = "SELECT id_historial, id_cita, evento, fecha_evento "
                + "FROM historial ORDER BY fecha_evento DESC";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new HistorialEvento(
                        rs.getInt("id_historial"),
                        rs.getInt("id_cita"),
                        rs.getString("evento"),
                        rs.getTimestamp("fecha_evento")
                ));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar historial:\n" + ex.getMessage());
        }
        return lista;
    }

    public void cargarTablaHistorial(DefaultTableModel modeloTabla) {
        modeloTabla.setRowCount(0);
        for (HistorialEvento h : listarTodo()) {
            Object[] fila = {
                h.getIdHistorial(),
                h.getIdCita(),
                h.getEvento(),
                h.getFechaEvento()
            };
            modeloTabla.addRow(fila);
        }
    }
}
