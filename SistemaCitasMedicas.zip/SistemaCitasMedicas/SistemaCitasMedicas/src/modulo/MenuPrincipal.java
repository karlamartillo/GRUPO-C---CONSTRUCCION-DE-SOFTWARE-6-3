package modulo;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import modulo.citas.VistaCita;
import modulo.medicos.VistaMedico;
import modulo.notificaciones.VistaHistorialNotificacion;
import modulo.pacientes.VistaPaciente;

/**
 * Ventana principal del sistema. Punto de entrada de la aplicacion.
 * Desde aqui se accede a los modulos de Pacientes, Medicos, Citas
 * e Historial/Notificaciones.
 */
public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Sistema de Gestion de Citas Medicas - Hospital Publico");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 350);
        setLocationRelativeTo(null);
        setLayout(new java.awt.GridLayout(5, 1, 10, 10));

        JLabel titulo = new JLabel("Sistema de Gestion de Citas Medicas", SwingConstants.CENTER);

        javax.swing.ImageIcon icono = new javax.swing.ImageIcon(getClass().getResource("/imagenes/logo_ug.png"));
        java.awt.Image imagenEscalada = icono.getImage().getScaledInstance(60, 60, java.awt.Image.SCALE_SMOOTH);
        titulo.setIcon(new javax.swing.ImageIcon(imagenEscalada));
        titulo.setHorizontalTextPosition(SwingConstants.RIGHT);

        JButton btnPacientes = new JButton("Gestion de Pacientes");
        JButton btnMedicos = new JButton("Gestion de Medicos");
        JButton btnCitas = new JButton("Gestion de Citas");
        JButton btnHistorial = new JButton("Historial y Notificaciones");

        add(titulo);
        add(btnPacientes);
        add(btnMedicos);
        add(btnCitas);
        add(btnHistorial);

        btnPacientes.addActionListener(e -> new VistaPaciente().setVisible(true));
        btnMedicos.addActionListener(e -> new VistaMedico().setVisible(true));
        btnCitas.addActionListener(e -> new VistaCita().setVisible(true));
        btnHistorial.addActionListener(e -> new VistaHistorialNotificacion().setVisible(true));
    }

    public static void main(String[] args) {
        System.setProperty("flatlaf.useNativeLibrary", "false");
        com.formdev.flatlaf.FlatLightLaf.setup();
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}