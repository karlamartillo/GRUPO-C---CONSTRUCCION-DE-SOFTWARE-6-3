package modulo.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * Clase encargada de centralizar la conexion a la base de datos SQL Server.
 * Aplica el patron Singleton para reutilizar una sola conexion en todo el sistema.
 */
public class Conexion {

    private static Conexion instancia;
    private Connection conexion;

    // ===== DATOS DE CONEXION =====
    private static final String SERVIDOR = "localhost\\SQLEXPRESS01";
    private static final String BASE_DATOS = "CitasMedicasDB";
    private static final String URL = "jdbc:sqlserver://" + SERVIDOR
            + ";databaseName=" + BASE_DATOS
            + ";encrypt=true;trustServerCertificate=true;";

    private static final String USUARIO = "citasapp";
    private static final String CLAVE = "Citas2026*";

    private Conexion() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error al conectar con la base de datos:\n" + ex.getMessage(),
                    "Error de conexion",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static Conexion getInstancia() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }

    public Connection getConexion() {
        return conexion;
    }
}