package modulo.citas;

import java.sql.Date;
import java.sql.Time;

public class Cita {

    private int idCita;
    private int idPaciente;
    private int idMedico;
    private String nombrePaciente; // solo para mostrar en tabla
    private String nombreMedico;   // solo para mostrar en tabla
    private Date fecha;
    private Time hora;
    private String estado; // "Pendiente", "Atendida" o "Cancelada"

    public Cita() {
    }

    public Cita(int idPaciente, int idMedico, Date fecha, Time hora) {
        this.idPaciente = idPaciente;
        this.idMedico = idMedico;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = "Pendiente";
    }

    public Cita(int idCita, int idPaciente, int idMedico, String nombrePaciente,
                String nombreMedico, Date fecha, Time hora, String estado) {
        this.idCita = idCita;
        this.idPaciente = idPaciente;
        this.idMedico = idMedico;
        this.nombrePaciente = nombrePaciente;
        this.nombreMedico = nombreMedico;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }

    public int getIdPaciente() { return idPaciente; }
    public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

    public int getIdMedico() { return idMedico; }
    public void setIdMedico(int idMedico) { this.idMedico = idMedico; }

    public String getNombrePaciente() { return nombrePaciente; }
    public void setNombrePaciente(String nombrePaciente) { this.nombrePaciente = nombrePaciente; }

    public String getNombreMedico() { return nombreMedico; }
    public void setNombreMedico(String nombreMedico) { this.nombreMedico = nombreMedico; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public Time getHora() { return hora; }
    public void setHora(Time hora) { this.hora = hora; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
