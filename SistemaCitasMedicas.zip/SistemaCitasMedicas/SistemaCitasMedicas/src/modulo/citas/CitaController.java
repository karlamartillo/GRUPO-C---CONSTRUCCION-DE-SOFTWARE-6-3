package modulo.citas;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modulo.conexion.Conexion;
import modulo.notificaciones.HistorialController;
import modulo.notificaciones.NotificacionController;

/**
 * Controlador encargado de la logica de negocio del modulo Citas.
 * Version corregida: ya no guarda en una ArrayList en memoria,
 * sino que persiste todo en la base de datos SQL Server.
 * Ademas, al registrar/cancelar una cita, genera el evento de
 * Historial y dispara la Notificacion correspondiente (integracion
 * con el modulo de Notificaciones).
 */
public class CitaController {

    private final Connection conexion;
    private final HistorialController historialController;
    private final NotificacionController notificacionController;

    public CitaController() {
        this.conexion = Conexion.getInstancia().getConexion();
        this.historialController = new HistorialController();
        this.notificacionController = new NotificacionController();
    }

    /**
     * Registra una nueva cita medica con estado inicial "Pendiente".
     */
    public boolean registrarCita(int idPaciente, int idMedico, Date fecha, Time hora) {

        if (idPaciente <= 0 || idMedico <= 0 || fecha == null || hora == null) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return false;
        }

        String sql = "INSERT INTO citas (id_paciente, id_medico, fecha, hora, estado) "
                + "VALUES (?, ?, ?, ?, 'Pendiente')";

        try (PreparedStatement ps = conexion.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, idPaciente);
            ps.setInt(2, idMedico);
            ps.setDate(3, fecha);
            ps.setTime(4, hora);
            ps.executeUpdate();

            ResultSet generadas = ps.getGeneratedKeys();
            int idCita = 0;
            if (generadas.next()) {
                idCita = generadas.getInt(1);
            }

            historialController.registrarEvento(idCita, "Cita creada y registrada como Pendiente.");
            notificacionController.notificarPaciente(idPaciente,
                    "Su cita medica fue registrada para el " + fecha + " a las " + hora + ".");

            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al registrar la cita:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Cambia el estado de la cita (ej. "Atendida" o "Cancelada").
     */
    public boolean modificarEstadoCita(int idCita, String nuevoEstado) {
        String sql = "UPDATE citas SET estado = ? WHERE id_cita = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt(2, idCita);
            int filas = ps.executeUpdate();

            if (filas > 0) {
                historialController.registrarEvento(idCita, "Estado de la cita cambiado a: " + nuevoEstado);

                int idPaciente = obtenerIdPacientePorCita(idCita);
                if (idPaciente > 0) {
                    notificacionController.notificarPaciente(idPaciente,
                            "El estado de su cita cambio a: " + nuevoEstado);
                }
                return true;
            }
            return false;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar la cita:\n" + ex.getMessage());
            return false;
        }
    }

    private int obtenerIdPacientePorCita(int idCita) throws SQLException {
        String sql = "SELECT id_paciente FROM citas WHERE id_cita = ?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idCita);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id_paciente");
            }
        }
        return -1;
    }

    /**
     * Lista todas las citas con datos legibles de paciente y medico (JOIN).
     */
    public ArrayList<Cita> listarCitas() {
        ArrayList<Cita> lista = new ArrayList<>();

        String sql = "SELECT c.id_cita, c.id_paciente, c.id_medico, "
                + "p.nombres + ' ' + p.apellidos AS nombre_paciente, "
                + "m.nombres + ' ' + m.apellidos AS nombre_medico, "
                + "c.fecha, c.hora, c.estado "
                + "FROM citas c "
                + "INNER JOIN pacientes p ON c.id_paciente = p.id_paciente "
                + "INNER JOIN medicos m ON c.id_medico = m.id_medico "
                + "ORDER BY c.fecha, c.hora";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Cita(
                        rs.getInt("id_cita"),
                        rs.getInt("id_paciente"),
                        rs.getInt("id_medico"),
                        rs.getString("nombre_paciente"),
                        rs.getString("nombre_medico"),
                        rs.getDate("fecha"),
                        rs.getTime("hora"),
                        rs.getString("estado")
                ));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar citas:\n" + ex.getMessage());
        }
        return lista;
    }

    /**
     * Llena un DefaultTableModel (tabla de Swing) con todas las citas.
     */
    public void cargarTablaCitas(DefaultTableModel modeloTabla) {
        modeloTabla.setRowCount(0);
        for (Cita c : listarCitas()) {
            Object[] fila = {
                c.getIdCita(),
                c.getNombrePaciente(),
                c.getNombreMedico(),
                c.getFecha(),
                c.getHora(),
                c.getEstado()
            };
            modeloTabla.addRow(fila);
        }
    }
}
