package modulo.citas;

import java.awt.GridLayout;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modulo.medicos.Medico;
import modulo.medicos.MedicoController;
import modulo.pacientes.Paciente;
import modulo.pacientes.PacienteController;

/**
 * Ventana de registro y administracion de citas medicas.
 * Version corregida: se eliminaron las rutas de imagen fijas que
 * apuntaban a una PC especifica, y los campos de ID escritos a mano
 * se reemplazaron por combos que se llenan desde la base de datos.
 */
public class VistaCita extends JFrame {

    private final CitaController controlador = new CitaController();
    private final PacienteController pacienteController = new PacienteController();
    private final MedicoController medicoController = new MedicoController();

    private DefaultTableModel modelo;
    private JComboBox<Paciente> comboPaciente;
    private JComboBox<Medico> comboMedico;
    private JTextField txtFecha;
    private JTextField txtHora;
    private JTable tablaCitas;

    public VistaCita() {
        initComponents();
        cargarCombos();
        controlador.cargarTablaCitas(modelo);
    }

    private void initComponents() {
        setTitle("Gestion de Citas Medicas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(750, 550);
        setLocationRelativeTo(null);
        setLayout(new java.awt.BorderLayout());

        JPanel panelFormulario = new JPanel(new GridLayout(6, 2, 5, 5));
        panelFormulario.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        comboPaciente = new JComboBox<>();
        comboMedico = new JComboBox<>();
        txtFecha = new JTextField();
        txtHora = new JTextField();

        panelFormulario.add(new JLabel("Paciente:"));
        panelFormulario.add(comboPaciente);
        panelFormulario.add(new JLabel("Medico:"));
        panelFormulario.add(comboMedico);
        panelFormulario.add(new JLabel("Fecha (AAAA-MM-DD):"));
        panelFormulario.add(txtFecha);
        panelFormulario.add(new JLabel("Hora (HH:MM:SS):"));
        panelFormulario.add(txtHora);

        JButton btnAgendar = new JButton("Agendar cita");
        JButton btnCancelar = new JButton("Cancelar seleccionada");
        JButton btnAtender = new JButton("Marcar como atendida");

        panelFormulario.add(btnAgendar);
        panelFormulario.add(btnCancelar);
        panelFormulario.add(btnAtender);

        modelo = new DefaultTableModel(
                new Object[]{"ID", "Paciente", "Medico", "Fecha", "Hora", "Estado"}, 0);
        tablaCitas = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaCitas);

        add(panelFormulario, java.awt.BorderLayout.NORTH);
        add(scroll, java.awt.BorderLayout.CENTER);

        btnAgendar.addActionListener(e -> agendarCita());
        btnCancelar.addActionListener(e -> cambiarEstadoSeleccionada("Cancelada"));
        btnAtender.addActionListener(e -> cambiarEstadoSeleccionada("Atendida"));
    }

    private void cargarCombos() {
        ArrayList<Paciente> pacientes = pacienteController.listarPacientes();
        for (Paciente p : pacientes) {
            comboPaciente.addItem(p);
        }

        ArrayList<Medico> medicos = medicoController.listarActivos();
        for (Medico m : medicos) {
            comboMedico.addItem(m);
        }
    }

    private void agendarCita() {
        Paciente paciente = (Paciente) comboPaciente.getSelectedItem();
        Medico medico = (Medico) comboMedico.getSelectedItem();

        if (paciente == null || medico == null) {
            JOptionPane.showMessageDialog(this, "Debe haber al menos un paciente y un medico registrado.");
            return;
        }

        try {
            Date fecha = Date.valueOf(txtFecha.getText().trim());
            Time hora = Time.valueOf(txtHora.getText().trim());

            boolean exito = controlador.registrarCita(paciente.getIdPaciente(), medico.getIdMedico(), fecha, hora);

            if (exito) {
                JOptionPane.showMessageDialog(this, "Cita registrada con exito.");
                txtFecha.setText("");
                txtHora.setText("");
                controlador.cargarTablaCitas(modelo);
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Formato invalido. Use AAAA-MM-DD para la fecha y HH:MM:SS para la hora.");
        }
    }

    private void cambiarEstadoSeleccionada(String nuevoEstado) {
        int fila = tablaCitas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cita de la tabla.");
            return;
        }

        int idCita = (int) modelo.getValueAt(fila, 0);
        boolean modificado = controlador.modificarEstadoCita(idCita, nuevoEstado);

        if (modificado) {
            JOptionPane.showMessageDialog(this, "Cita actualizada a: " + nuevoEstado);
            controlador.cargarTablaCitas(modelo);
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo actualizar la cita.");
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new VistaCita().setVisible(true));
    }
}
