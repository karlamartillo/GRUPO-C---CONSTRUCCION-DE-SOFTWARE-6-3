package modulo.pacientes;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana de registro y administracion de pacientes.
 */
public class VistaPaciente extends JFrame {

    private final PacienteController controlador = new PacienteController();
    private DefaultTableModel modelo;

    private JTextField txtCedula;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTable tablaPacientes;

    public VistaPaciente() {
        initComponents();
        controlador.cargarTablaPacientes(modelo);
    }

    private void initComponents() {
        setTitle("Gestion de Pacientes");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(650, 500);
        setLocationRelativeTo(null);
        setLayout(new java.awt.BorderLayout());

        JPanel panelFormulario = new JPanel(new GridLayout(6, 2, 5, 5));
        panelFormulario.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtCedula = new JTextField();
        txtNombres = new JTextField();
        txtApellidos = new JTextField();
        txtTelefono = new JTextField();
        txtCorreo = new JTextField();

        panelFormulario.add(new JLabel("Cedula:"));
        panelFormulario.add(txtCedula);
        panelFormulario.add(new JLabel("Nombres:"));
        panelFormulario.add(txtNombres);
        panelFormulario.add(new JLabel("Apellidos:"));
        panelFormulario.add(txtApellidos);
        panelFormulario.add(new JLabel("Telefono:"));
        panelFormulario.add(txtTelefono);
        panelFormulario.add(new JLabel("Correo:"));
        panelFormulario.add(txtCorreo);

        JButton btnRegistrar = new JButton("Registrar");
        JButton btnEliminar = new JButton("Eliminar seleccionado");

        panelFormulario.add(btnRegistrar);
        panelFormulario.add(btnEliminar);

        modelo = new DefaultTableModel(
                new Object[]{"ID", "Cedula", "Nombres", "Apellidos", "Telefono", "Correo"}, 0);
        tablaPacientes = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaPacientes);

        add(panelFormulario, java.awt.BorderLayout.NORTH);
        add(scroll, java.awt.BorderLayout.CENTER);

        btnRegistrar.addActionListener(e -> registrar());
        btnEliminar.addActionListener(e -> eliminarSeleccionado());
    }

    private void registrar() {
        boolean exito = controlador.registrarPaciente(
                txtCedula.getText().trim(),
                txtNombres.getText().trim(),
                txtApellidos.getText().trim(),
                txtTelefono.getText().trim(),
                txtCorreo.getText().trim()
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "Paciente registrado con exito.");
            limpiarCampos();
            controlador.cargarTablaPacientes(modelo);
        }
    }

    private void eliminarSeleccionado() {
        int fila = tablaPacientes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un paciente de la tabla.");
            return;
        }

        int idPaciente = (int) modelo.getValueAt(fila, 0);
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "Desea eliminar al paciente seleccionado?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            if (controlador.eliminarPaciente(idPaciente)) {
                JOptionPane.showMessageDialog(this, "Paciente eliminado.");
                controlador.cargarTablaPacientes(modelo);
            }
        }
    }

    private void limpiarCampos() {
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new VistaPaciente().setVisible(true));
    }
}
