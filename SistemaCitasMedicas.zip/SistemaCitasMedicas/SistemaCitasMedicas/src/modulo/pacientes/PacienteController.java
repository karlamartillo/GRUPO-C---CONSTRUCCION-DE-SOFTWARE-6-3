package modulo.pacientes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modulo.conexion.Conexion;

/**
 * Controlador encargado de la logica de negocio del modulo Pacientes.
 * Se comunica con la base de datos SQL Server mediante JDBC.
 */
public class PacienteController {

    private final Connection conexion;

    public PacienteController() {
        this.conexion = Conexion.getInstancia().getConexion();
    }

    /**
     * Registra un nuevo paciente. Valida campos vacios y cedula duplicada.
     */
    public boolean registrarPaciente(String cedula, String nombres, String apellidos,
                                      String telefono, String correo) {

        if (cedula.isEmpty() || nombres.isEmpty() || apellidos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Cedula, nombres y apellidos son obligatorios.");
            return false;
        }

        if (cedula.length() != 10) {
            JOptionPane.showMessageDialog(null, "La cedula debe tener 10 digitos.");
            return false;
        }

        if (existeCedula(cedula)) {
            JOptionPane.showMessageDialog(null, "Ya existe un paciente registrado con esa cedula.");
            return false;
        }

        String sql = "INSERT INTO pacientes (cedula, nombres, apellidos, telefono, correo) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, cedula);
            ps.setString(2, nombres);
            ps.setString(3, apellidos);
            ps.setString(4, telefono);
            ps.setString(5, correo);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al registrar paciente:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Actualiza los datos de un paciente existente.
     */
    public boolean actualizarPaciente(int idPaciente, String nombres, String apellidos,
                                       String telefono, String correo) {

        String sql = "UPDATE pacientes SET nombres = ?, apellidos = ?, telefono = ?, correo = ? "
                + "WHERE id_paciente = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nombres);
            ps.setString(2, apellidos);
            ps.setString(3, telefono);
            ps.setString(4, correo);
            ps.setInt(5, idPaciente);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar paciente:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Elimina un paciente por su id.
     */
    public boolean eliminarPaciente(int idPaciente) {
        String sql = "DELETE FROM pacientes WHERE id_paciente = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPaciente);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "No se pudo eliminar. Verifique que el paciente no tenga citas asociadas.\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Busca un paciente por cedula.
     */
    public Paciente buscarPorCedula(String cedula) {
        String sql = "SELECT id_paciente, cedula, nombres, apellidos, telefono, correo "
                + "FROM pacientes WHERE cedula = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, cedula);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapearPaciente(rs);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al buscar paciente:\n" + ex.getMessage());
        }
        return null;
    }

    /**
     * Lista todos los pacientes registrados.
     */
    public ArrayList<Paciente> listarPacientes() {
        ArrayList<Paciente> lista = new ArrayList<>();
        String sql = "SELECT id_paciente, cedula, nombres, apellidos, telefono, correo "
                + "FROM pacientes ORDER BY apellidos";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapearPaciente(rs));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar pacientes:\n" + ex.getMessage());
        }
        return lista;
    }

    /**
     * Llena un DefaultTableModel (tabla de Swing) con todos los pacientes.
     */
    public void cargarTablaPacientes(DefaultTableModel modeloTabla) {
        modeloTabla.setRowCount(0);
        for (Paciente p : listarPacientes()) {
            Object[] fila = {
                p.getIdPaciente(),
                p.getCedula(),
                p.getNombres(),
                p.getApellidos(),
                p.getTelefono(),
                p.getCorreo()
            };
            modeloTabla.addRow(fila);
        }
    }

    private boolean existeCedula(String cedula) {
        return buscarPorCedula(cedula) != null;
    }

    private Paciente mapearPaciente(ResultSet rs) throws SQLException {
        return new Paciente(
                rs.getInt("id_paciente"),
                rs.getString("cedula"),
                rs.getString("nombres"),
                rs.getString("apellidos"),
                rs.getString("telefono"),
                rs.getString("correo")
        );
    }
}
