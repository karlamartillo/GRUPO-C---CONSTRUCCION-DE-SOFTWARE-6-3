package modulo.medicos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modulo.conexion.Conexion;

/**
 * Controlador encargado de la logica de negocio del modulo Medicos.
 * Equivalente al MedicoService/MedicoController original, adaptado
 * de Spring Boot a una aplicacion de escritorio Java con JDBC.
 */
public class MedicoController {

    private final Connection conexion;

    public MedicoController() {
        this.conexion = Conexion.getInstancia().getConexion();
    }

    public boolean registrarMedico(String cedula, String nombres, String apellidos,
                                    String especialidad, String correo, String telefono) {

        if (cedula.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || especialidad.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Cedula, nombres, apellidos y especialidad son obligatorios.");
            return false;
        }

        if (cedula.length() != 10) {
            JOptionPane.showMessageDialog(null, "La cedula debe tener 10 digitos.");
            return false;
        }

        if (existeCedula(cedula)) {
            JOptionPane.showMessageDialog(null, "Ya existe un medico con esa cedula.");
            return false;
        }

        String sql = "INSERT INTO medicos (cedula, nombres, apellidos, especialidad, correo, telefono, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?, 'ACTIVO')";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, cedula);
            ps.setString(2, nombres);
            ps.setString(3, apellidos);
            ps.setString(4, especialidad);
            ps.setString(5, correo);
            ps.setString(6, telefono);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al registrar medico:\n" + ex.getMessage());
            return false;
        }
    }

    public boolean actualizarMedico(int idMedico, String nombres, String apellidos,
                                     String especialidad, String correo, String telefono) {

        String sql = "UPDATE medicos SET nombres = ?, apellidos = ?, especialidad = ?, "
                + "correo = ?, telefono = ? WHERE id_medico = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nombres);
            ps.setString(2, apellidos);
            ps.setString(3, especialidad);
            ps.setString(4, correo);
            ps.setString(5, telefono);
            ps.setInt(6, idMedico);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar medico:\n" + ex.getMessage());
            return false;
        }
    }

    /**
     * Eliminacion logica: en vez de borrar el registro, lo marca como INACTIVO.
     * Esto evita romper las citas ya asociadas a ese medico.
     */
    public boolean eliminarLogico(int idMedico) {
        String sql = "UPDATE medicos SET estado = 'INACTIVO' WHERE id_medico = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idMedico);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al desactivar medico:\n" + ex.getMessage());
            return false;
        }
    }

    public Medico buscarPorCedula(String cedula) {
        String sql = "SELECT id_medico, cedula, nombres, apellidos, especialidad, correo, telefono, estado "
                + "FROM medicos WHERE cedula = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, cedula);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapearMedico(rs);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al buscar medico:\n" + ex.getMessage());
        }
        return null;
    }

    public ArrayList<Medico> listarActivos() {
        ArrayList<Medico> lista = new ArrayList<>();
        String sql = "SELECT id_medico, cedula, nombres, apellidos, especialidad, correo, telefono, estado "
                + "FROM medicos WHERE estado = 'ACTIVO' ORDER BY apellidos";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapearMedico(rs));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar medicos:\n" + ex.getMessage());
        }
        return lista;
    }

    public void cargarTablaMedicos(DefaultTableModel modeloTabla) {
        modeloTabla.setRowCount(0);
        for (Medico m : listarActivos()) {
            Object[] fila = {
                m.getIdMedico(),
                m.getCedula(),
                m.getNombres(),
                m.getApellidos(),
                m.getEspecialidad(),
                m.getTelefono(),
                m.getEstado()
            };
            modeloTabla.addRow(fila);
        }
    }

    private boolean existeCedula(String cedula) {
        return buscarPorCedula(cedula) != null;
    }

    private Medico mapearMedico(ResultSet rs) throws SQLException {
        return new Medico(
                rs.getInt("id_medico"),
                rs.getString("cedula"),
                rs.getString("nombres"),
                rs.getString("apellidos"),
                rs.getString("especialidad"),
                rs.getString("correo"),
                rs.getString("telefono"),
                rs.getString("estado")
        );
    }
}
