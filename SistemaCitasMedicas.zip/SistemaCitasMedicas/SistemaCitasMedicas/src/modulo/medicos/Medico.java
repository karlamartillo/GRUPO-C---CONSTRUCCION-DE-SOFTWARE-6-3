package modulo.medicos;

public class Medico {

    private int idMedico;
    private String cedula;
    private String nombres;
    private String apellidos;
    private String especialidad;
    private String correo;
    private String telefono;
    private String estado;

    public Medico() {
        this.estado = "ACTIVO";
    }

    public Medico(String cedula, String nombres, String apellidos, String especialidad,
                  String correo, String telefono) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.especialidad = especialidad;
        this.correo = correo;
        this.telefono = telefono;
        this.estado = "ACTIVO";
    }

    public Medico(int idMedico, String cedula, String nombres, String apellidos, String especialidad,
                  String correo, String telefono, String estado) {
        this.idMedico = idMedico;
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.especialidad = especialidad;
        this.correo = correo;
        this.telefono = telefono;
        this.estado = estado;
    }

    public int getIdMedico() { return idMedico; }
    public void setIdMedico(int idMedico) { this.idMedico = idMedico; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return nombres + " " + apellidos + " - " + especialidad;
    }
}
