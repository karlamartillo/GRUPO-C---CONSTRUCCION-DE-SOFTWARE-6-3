package modulo.medicos;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana de registro y administracion de medicos.
 */
public class VistaMedico extends JFrame {

    private final MedicoController controlador = new MedicoController();
    private DefaultTableModel modelo;

    private JTextField txtCedula;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtEspecialidad;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTable tablaMedicos;

    public VistaMedico() {
        initComponents();
        controlador.cargarTablaMedicos(modelo);
    }

    private void initComponents() {
        setTitle("Gestion de Medicos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setLayout(new java.awt.BorderLayout());

        JPanel panelFormulario = new JPanel(new GridLayout(7, 2, 5, 5));
        panelFormulario.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtCedula = new JTextField();
        txtNombres = new JTextField();
        txtApellidos = new JTextField();
        txtEspecialidad = new JTextField();
        txtTelefono = new JTextField();
        txtCorreo = new JTextField();

        panelFormulario.add(new JLabel("Cedula:"));
        panelFormulario.add(txtCedula);
        panelFormulario.add(new JLabel("Nombres:"));
        panelFormulario.add(txtNombres);
        panelFormulario.add(new JLabel("Apellidos:"));
        panelFormulario.add(txtApellidos);
        panelFormulario.add(new JLabel("Especialidad:"));
        panelFormulario.add(txtEspecialidad);
        panelFormulario.add(new JLabel("Telefono:"));
        panelFormulario.add(txtTelefono);
        panelFormulario.add(new JLabel("Correo:"));
        panelFormulario.add(txtCorreo);

        JButton btnRegistrar = new JButton("Registrar");
        JButton btnDesactivar = new JButton("Desactivar seleccionado");

        panelFormulario.add(btnRegistrar);
        panelFormulario.add(btnDesactivar);

        modelo = new DefaultTableModel(
                new Object[]{"ID", "Cedula", "Nombres", "Apellidos", "Especialidad", "Telefono", "Estado"}, 0);
        tablaMedicos = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaMedicos);

        add(panelFormulario, java.awt.BorderLayout.NORTH);
        add(scroll, java.awt.BorderLayout.CENTER);

        btnRegistrar.addActionListener(e -> registrar());
        btnDesactivar.addActionListener(e -> desactivarSeleccionado());
    }

    private void registrar() {
        boolean exito = controlador.registrarMedico(
                txtCedula.getText().trim(),
                txtNombres.getText().trim(),
                txtApellidos.getText().trim(),
                txtEspecialidad.getText().trim(),
                txtCorreo.getText().trim(),
                txtTelefono.getText().trim()
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "Medico registrado con exito.");
            limpiarCampos();
            controlador.cargarTablaMedicos(modelo);
        }
    }

    private void desactivarSeleccionado() {
        int fila = tablaMedicos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un medico de la tabla.");
            return;
        }

        int idMedico = (int) modelo.getValueAt(fila, 0);
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "Desea desactivar al medico seleccionado?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            if (controlador.eliminarLogico(idMedico)) {
                JOptionPane.showMessageDialog(this, "Medico desactivado.");
                controlador.cargarTablaMedicos(modelo);
            }
        }
    }

    private void limpiarCampos() {
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtEspecialidad.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new VistaMedico().setVisible(true));
    }
}
